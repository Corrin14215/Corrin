# Create component labor card

## What will change

- Build a single card UI that presents the requested component and aircraft labor details.
- Keep the app focused on one page with no navigation chrome.
- Use a structured card layout with grouped details for part identification, labor hours, aircraft transfer, component status, and approval.
- Apply a purpose-matched aviation maintenance visual theme in the app CSS before changing the card UI.

## Card fields

- Date
- NSN
- MPN
- Description
- Component description
- Removal MH
- Installation MH
- FOM MH
- Donor aircraft
- Receiver aircraft
- Component status: Legacy or MLU
- Approved by

## Data

- Use sample in-app data for the card unless live or editable records are requested later.
- No new persistent data entities are needed for this single display card.

## What stays simple

- No extra pages, navigation, login, account menu, or unrelated workflow.
- No form editing, filtering, approvals workflow, or database setup unless requested as a plan revision.
