import { useMemo } from 'react';
import { ArrowLeft, CheckCircle2, ClipboardCheck, Database } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

type LaborRecord = {
  id: string;
  date: string;
  requestName: string;
  requesterEmail: string;
  nsn: string;
  mpn: string;
  description: string;
  component: string;
  lruCategory: string;
  itemClass: string;
  platform: string;
  trade: string;
  donorAircraft: string;
  receiverAircraft: string;
  aircraftRemarks: string;
  removalMh: string;
  installationMh: string;
  fomMh: string;
  endorsedBy: string;
  endorsedBy2: string;
  concurredBy: string;
  concurredBy2: string;
  approvingBy: string;
  esNotificationNumber: string;
  note: string;
};

type ReviewItem = { label: string; value: string };
type ReviewSection = { title: string; items: ReviewItem[] };

export default function ReviewPage() {
  const navigate = useNavigate();
  const record = useMemo<LaborRecord | null>(() => {
    const savedDraft = sessionStorage.getItem('component-labor-draft');
    if (!savedDraft) return null;
    try {
      return JSON.parse(savedDraft) as LaborRecord;
    } catch {
      return null;
    }
  }, []);

  if (!record) {
    return (
      <main className="flex flex-1 items-center justify-center bg-background p-4">
        <Card className="w-full max-w-lg bg-card text-card-foreground">
          <CardHeader><CardTitle>No request to review</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">Complete the request form before opening the review page.</p>
            <Button type="button" onClick={() => navigate('/')}>Return to form</Button>
          </CardContent>
        </Card>
      </main>
    );
  }

  const totalMh = Number(record.removalMh || 0) + Number(record.installationMh || 0) + Number(record.fomMh || 0);
  const sections: ReviewSection[] = [
    { title: 'Request details', items: [
      { label: "Requester's Rank/Name", value: record.requestName }, { label: "Requester's Email", value: record.requesterEmail },
      { label: 'Request date', value: record.date },
    ] },
    { title: 'Item details', items: [
      { label: 'Description', value: record.description }, { label: 'MPN', value: record.mpn },
      { label: 'NSN', value: record.nsn }, { label: 'Platform', value: record.platform },
      { label: 'Trade', value: record.trade }, { label: 'Component type', value: record.component },
      { label: 'LRU category', value: record.lruCategory }, { label: 'Item class', value: record.itemClass },
    ] },
    { title: 'Aircraft and effort', items: [
      { label: 'Donor aircraft', value: record.donorAircraft }, { label: 'Receiver aircraft', value: record.receiverAircraft },
      { label: 'Removal MHs', value: record.removalMh }, { label: 'Installation MHs', value: record.installationMh },
      { label: 'FOM MHs', value: record.fomMh }, { label: 'Total MHs', value: totalMh.toFixed(1) },
      { label: 'Justification', value: record.aircraftRemarks },
    ] },
    { title: 'Approval flow', items: [
      { label: 'Endorser 1', value: record.endorsedBy }, { label: 'Endorser 2', value: record.endorsedBy2 ?? '' },
      { label: 'Concurrer 1', value: record.concurredBy }, { label: 'Concurrer 2', value: record.concurredBy2 ?? '' },
      { label: 'Approved by', value: record.approvingBy },
      { label: 'ES notification number', value: record.esNotificationNumber },
      { label: 'Additional remarks', value: record.note },
    ] },
  ];

  const confirmRequest = () => {
    sessionStorage.removeItem('component-labor-draft');
    toast.success('Request confirmed. SharePoint list creation is simulated for now.');
    navigate('/');
  };

  return (
    <main className="flex flex-1 justify-center bg-background px-3 py-4 sm:px-6 sm:py-6">
      <div className="w-full max-w-5xl space-y-4 sm:space-y-6">
        <Card className="border-border bg-card text-card-foreground shadow-sm">
          <CardHeader className="border-b border-border bg-card p-4 sm:p-6">
            <div className="flex items-start gap-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <ClipboardCheck className="h-5 w-5" aria-hidden="true" />
              </span>
              <div className="space-y-1">
                <CardTitle className="text-xl sm:text-2xl">Review request</CardTitle>
                <p className="text-sm text-muted-foreground">Check each detail before confirming the request for list creation.</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-5 p-4 sm:p-6">
            <div className="flex items-start gap-3 rounded-md border border-border bg-muted p-4 text-foreground">
              <Database className="mt-0.5 h-5 w-5 shrink-0" aria-hidden="true" />
              <div>
                <p className="font-semibold">SharePoint connection pending</p>
                <p className="text-sm text-muted-foreground">Confirm currently simulates creating a new list item. No SharePoint data will be written yet.</p>
              </div>
            </div>

            {sections.map((section: ReviewSection) => (
              <section key={section.title} className="overflow-hidden rounded-lg border border-border bg-card text-card-foreground">
                <h2 className="border-b border-border bg-muted px-4 py-3 font-semibold text-foreground">{section.title}</h2>
                <dl className="grid sm:grid-cols-2 lg:grid-cols-3">
                  {section.items.map((item: ReviewItem) => (
                    <div key={item.label} className="min-w-0 border-b border-border p-4 last:border-b-0 sm:border-r">
                      <dt className="text-sm font-medium text-muted-foreground">{item.label}</dt>
                      <dd className="mt-1 break-words font-medium text-foreground">{item.value.trim() || 'Not provided'}</dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}

            <Separator />
            <div className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
              <Button type="button" variant="outline" onClick={() => navigate('/')}>
                <ArrowLeft className="h-4 w-4" aria-hidden="true" />
                Edit request
              </Button>
              <Button type="button" onClick={confirmRequest}>
                <CheckCircle2 className="h-4 w-4" aria-hidden="true" />
                Confirm request
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
