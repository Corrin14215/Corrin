import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarIcon, FileText, Send } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

type LaborRecord = {
  id: string;
  date: string;
  requestName: string;
  requesterEmail: string;
  nsn: string;
  mpn: string;
  description: string;
  component: string;
  lruCategory: string;
  itemClass: string;

  platform: string;
  trade: string;
  donorAircraft: string;
  receiverAircraft: string;
  aircraftRemarks: string;
  removalMh: string;
  installationMh: string;
  fomMh: string;
  endorsedBy: string;
  endorsedBy2: string;
  concurredBy: string;
  concurredBy2: string;
  approvingBy: string;
  esNotificationNumber: string;
  note: string;
};

const itemClassOptions = [
  'R - Repairable',
  'C - Non-repairable',
];
const categories = [
  { code: 'A', description: 'Life controlled items', approvingParty: '' },
  { code: 'B', description: 'Structural Significant Items (SSI) and components', approvingParty: 'Seek concurrence from Hd SC after approval given' },
  { code: 'C', description: 'Helicopter Roter Tx System', approvingParty: 'Seek concurrence from Hd AeC after approval given' },
  { code: 'D', description: 'All others outside A, B, C, E', approvingParty: '' },
  { code: 'E', description: 'Critical engine parts/module', approvingParty: 'Seek concurrence from Hd PPC after approval given' },
];
const lruCategoryOptions = categories.map(
  (category: { code: string; description: string }) => `${category.code} - ${category.description}`,
);

const componentOptions = ['Legacy/Vanilla', 'UG', 'Common', 'Common D+', 'NA (G550)'];
const platformOptions = ['F16', 'G550'];
const tradeOptions = ['AE', 'AW', 'CN', 'EI', 'FC', 'PR', 'SF', 'AV (G550)', 'AE (G550)', 'MS (G550)'];
const aircraftOptions = ['K08CU', 'K10CU', 'K11CU', 'K12CU', 'K13CU', 'K14CU', 'K15C', 'K20CU', 'K21CU', 'K41CU', 'K42C', 'K45CU', 'K46C', 'K23DU', 'K24H', 'K25DU', 'K26H', 'K27DU', 'K38DU', 'K40H', 'K91DU', 'K92H', 'K95DU', 'K96DU'];
const donorAircraftOptions = [
  ...aircraftOptions.slice(0, -2),
  'K94DU',
  ...aircraftOptions.slice(-2),
  'K09CU', 'K32DU', 'K39DU', 'K62DU+', 'K63DU+', 'K65DU+', 'K69DU+', 'K73DU+', 'K77D+', 'K78DU+', 'K79DU+',
  'K03CV', 'K04CV', 'K05CV', 'K17CV', 'C18CV', 'K29DV', 'K31DV', 'K33DV', 'K37DV', 'K48DV', 'K93DV',
  'P10', 'P16', 'P17', 'P18',
];
const receiverAircraftOptions = [
  ...aircraftOptions.slice(0, -2),
  'K94DU',
  ...aircraftOptions.slice(-2),
  'K09CU', 'K32DU', 'K39DU', 'K62DU+', 'K63DU+', 'K65DU+', 'K69DU+', 'K73DU+', 'K77D+', 'K78DU+', 'K79DU+',
  'K03CV', 'K04CV', 'K05CV', 'K17CV', 'K18CV', 'K29DV', 'K31DV', 'K33DV', 'K37DV', 'K48DV', 'K93DV',
  'P10', 'P16', 'P17', 'P18', 'T/R Spare',
];


const requiredFields: Array<keyof LaborRecord> = [
  'date', 'requestName', 'requesterEmail', 'nsn', 'mpn', 'description', 'component', 'lruCategory', 'itemClass', 'platform', 'trade', 'donorAircraft', 'receiverAircraft', 'aircraftRemarks',
  'removalMh', 'installationMh', 'fomMh', 'approvingBy',
];


const createBlankRecord = (id: string): LaborRecord => ({

  id,
  requesterEmail: '',
  requestName: '',
  date: '',
  nsn: '',
  mpn: '',
  lruCategory: '',
  description: '',
  component: 'Legacy/Vanilla',
  platform: 'F16',
  itemClass: '',
  trade: 'AE',
  donorAircraft: 'K08CU',
  aircraftRemarks: '',
  receiverAircraft: 'K10CU',
  removalMh: '',
  installationMh: '',
  fomMh: '',
  endorsedBy2: '',
  endorsedBy: '',
  concurredBy2: '',
  concurredBy: '',
  approvingBy: '',
  esNotificationNumber: '',
  note: '',
});





const getDateFromValue = (value: string) => {
  if (!value) {
    return undefined;
  }

  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? undefined : date;
};

const getRecordTotalMh = (record: LaborRecord) =>
  Number(record.removalMh || 0) + Number(record.installationMh || 0) + Number(record.fomMh || 0);

export default function HomePage() {
  const navigate = useNavigate();
  const [draftRecord, setDraftRecord] = useState<LaborRecord>(() => {
    const savedDraft = sessionStorage.getItem('component-labor-draft');
    if (!savedDraft) return createBlankRecord('CL-001');
    try {
      return JSON.parse(savedDraft) as LaborRecord;
    } catch {
      return createBlankRecord('CL-001');
    }
  });

  const [missingFields, setMissingFields] = useState<Set<keyof LaborRecord>>(new Set());

  const updateDraftRecord = (field: keyof LaborRecord, value: string) => {
    setDraftRecord((currentRecord: LaborRecord) => ({ ...currentRecord, [field]: value }));
    setMissingFields((currentFields: Set<keyof LaborRecord>) => {
      const nextFields = new Set(currentFields);
      if (value.trim()) nextFields.delete(field);
      return nextFields;
    });
  };

  const validateRequiredFields = (action: string) => {
    const missing = requiredFields.filter((field: keyof LaborRecord) => !draftRecord[field].trim());
    setMissingFields(new Set(missing));
    if (missing.length > 0) {
      toast.error(`Complete all compulsory fields before ${action}.`);
      return false;
    }
    return true;
  };

  const submitLaborCard = () => {
    if (!validateRequiredFields('reviewing')) return;
    sessionStorage.setItem('component-labor-draft', JSON.stringify(draftRecord));
    navigate('/review');
  };





  return (
    <main className="flex flex-1 justify-center bg-background px-3 py-4 sm:px-6 sm:py-6">
      <div className="w-full max-w-5xl space-y-4 sm:space-y-6">
        <Card className="print-card border-border bg-card text-card-foreground shadow-sm">
          <CardHeader className="border-b border-border bg-card p-4 text-card-foreground sm:p-6">
            <div className="flex flex-col gap-3 sm:gap-4 lg:flex-row lg:items-center lg:justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-semibold uppercase">
                  <FileText className="h-5 w-5" aria-hidden="true" />
                  Cannibalisation
                </div>
                <CardTitle className="text-xl font-bold uppercase tracking-tight sm:text-2xl">Component Transfer Portal</CardTitle>
                <p className="max-w-3xl text-sm text-muted-foreground sm:text-base">
                  Submit a new cannibalisation request

                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 p-4 sm:space-y-6 sm:p-6">
            <RecordCard
              record={draftRecord}
              title="Cannibalisation Request"
              description="Complete the request, then continue to review before confirming."
              onChange={updateDraftRecord}
              onSubmit={submitLaborCard}
              missingFields={missingFields}
              totalMh={getRecordTotalMh(draftRecord)}
            />
          </CardContent>
        </Card>
      </div>
    </main>
  );
}



type RecordCardProps = {
  record: LaborRecord;
  title: string;
  description: string;
  onChange: (field: keyof LaborRecord, value: string) => void;
  onSubmit: () => void;
  missingFields: Set<keyof LaborRecord>;
  totalMh: number;
};

function RecordCard({ record, title, description, onChange, onSubmit, missingFields, totalMh }: RecordCardProps) {
  return (
    <Card className="border-border bg-card text-card-foreground shadow-sm">
      <CardHeader className="border-b border-border bg-muted p-4 text-foreground sm:p-6">
        <div>
          <CardTitle className="text-base uppercase sm:text-lg">{title}</CardTitle>
          <p className="text-sm text-muted-foreground">{description}</p>
          <p className="mt-1 text-sm font-semibold text-foreground">Mandatory field is required*</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-4 p-4 sm:space-y-5 sm:p-5">

        <FormSection number="1" title="Request Details">
          <DatePickerField label="Request Date" value={record.date} required error={missingFields.has('date')} onChange={(value: string) => onChange('date', value)} />
          <TextField label="Requester's Rank/Name" value={record.requestName} required error={missingFields.has('requestName')} onChange={(value: string) => onChange('requestName', value)} />
          <TextField label="Requester's Email" value={record.requesterEmail} inputMode="email" required error={missingFields.has('requesterEmail')} onChange={(value: string) => onChange('requesterEmail', value)} />
        </FormSection>

        <FormSection number="2" title="Item Details">
          <TextField label="Description" value={record.description} required error={missingFields.has('description')} onChange={(value: string) => onChange('description', value)} />
          <TextField label="MPN" value={record.mpn} required error={missingFields.has('mpn')} onChange={(value: string) => onChange('mpn', value)} />
          <TextField label="NSN" value={record.nsn} required error={missingFields.has('nsn')} onChange={(value: string) => onChange('nsn', value)} />
          <CardSelect label="Platform" value={record.platform} options={platformOptions} required error={missingFields.has('platform')} onChange={(value: string) => onChange('platform', value)} />
          <CardSelect label="Trade" value={record.trade} options={tradeOptions} required error={missingFields.has('trade')} onChange={(value: string) => onChange('trade', value)} />
          <CardSelect label="Component Type" value={record.component} options={componentOptions} required error={missingFields.has('component')} onChange={(value: string) => onChange('component', value)} />
          <CardSelect label="LRU Category" value={record.lruCategory} options={lruCategoryOptions} required error={missingFields.has('lruCategory')} onChange={(value: string) => onChange('lruCategory', value)} />
          <CardSelect label="Item Class" value={record.itemClass} options={itemClassOptions} required error={missingFields.has('itemClass')} onChange={(value: string) => onChange('itemClass', value)} />


        </FormSection>


        <FormSection number="3" title="A/C Details">
          <CardSelect label="Donor aircraft" value={record.donorAircraft} options={donorAircraftOptions} required error={missingFields.has('donorAircraft')} onChange={(value: string) => onChange('donorAircraft', value)} />
          <CardSelect label="Receiver aircraft" value={record.receiverAircraft} options={receiverAircraftOptions} required error={missingFields.has('receiverAircraft')} onChange={(value: string) => onChange('receiverAircraft', value)} />
          <label className="space-y-1 text-sm font-medium text-foreground sm:col-span-2 lg:col-span-3">
            Justification <span aria-hidden="true">*</span>
            <Textarea
              value={record.aircraftRemarks}
              placeholder="Include Detachment name when applicable"
              required
              aria-invalid={missingFields.has('aircraftRemarks')}
              onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => onChange('aircraftRemarks', event.target.value)}
              className="min-h-24 resize-y bg-background text-foreground"
            />
            {missingFields.has('aircraftRemarks') && <span className="text-sm text-destructive">This field is required.</span>}
          </label>
        </FormSection>

        <FormSection number="4" title="CANNIBALISATION EFFORTS">
          <TextField label="Removal MHs" value={record.removalMh} inputMode="decimal" placeholder="Numbers only" required error={missingFields.has('removalMh')} onChange={(value: string) => onChange('removalMh', value)} />
          <TextField label="Installation MHs" value={record.installationMh} inputMode="decimal" placeholder="Numbers only" required error={missingFields.has('installationMh')} onChange={(value: string) => onChange('installationMh', value)} />
          <TextField label="FOM MHs" value={record.fomMh} inputMode="decimal" placeholder="Numbers only" required error={missingFields.has('fomMh')} onChange={(value: string) => onChange('fomMh', value)} />
          <label className="space-y-1 text-sm font-medium text-foreground">
            Total MHs
            <Input value={totalMh.toFixed(1)} readOnly className="bg-muted text-foreground" />
          </label>
        </FormSection>

        <FormSection number="5" title="Approval Flow">
          <div className="grid gap-4 lg:grid-cols-[minmax(15rem,0.8fr)_minmax(28rem,1.5fr)] lg:col-span-3">
            <div className="grid content-start gap-3">
              <p className="font-bold underline">Refer to Approval Reference by Scenario</p>
              <TextField label="Endorser 1" value={record.endorsedBy} inputMode="email" placeholder="Defence Mail of Endorser, or NA if not applicable" onChange={(value: string) => onChange('endorsedBy', value)} />
              <TextField label="Endorser 2" value={record.endorsedBy2} inputMode="email" placeholder="Defence Mail of second Endorser, or NA if not applicable" onChange={(value: string) => onChange('endorsedBy2', value)} />
              <TextField label="Concurrer 1" value={record.concurredBy} inputMode="email" placeholder="Defence Mail of Concurrer, or NA if not applicable" onChange={(value: string) => onChange('concurredBy', value)} />
              <TextField label="Concurrer 2" value={record.concurredBy2} inputMode="email" placeholder="Defence Mail of second Concurrer, or NA if not applicable" onChange={(value: string) => onChange('concurredBy2', value)} />
              <TextField label="Approved By" value={record.approvingBy} inputMode="email" placeholder="Defence Mail of Approver" required error={missingFields.has('approvingBy')} onChange={(value: string) => onChange('approvingBy', value)} />
            </div>

            <div className="overflow-hidden rounded-md border border-border bg-card text-card-foreground">
              <div className="border-b border-border bg-muted px-3 py-2 text-sm font-semibold uppercase text-foreground">Approval reference by scenario</div>
              <Table>
                <TableHeader className="uppercase">
                  <TableRow>
                    <TableHead>Scenario</TableHead>
                    <TableHead>Request time</TableHead>
                    <TableHead>Endorser 1</TableHead>
                    <TableHead>Endorser 2</TableHead>
                    <TableHead>Concurrer 1</TableHead>
                    <TableHead>Concurrer 2</TableHead>
                    <TableHead>Approver</TableHead>
                    <TableHead>Remarks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">Base aircraft</TableCell>
                    <TableCell>0700-1900H</TableCell>
                    <TableCell>OC MCF</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell rowSpan={5} className="min-w-32 align-middle text-center">
                      <div className="space-y-1 whitespace-nowrap text-center">
                        <div>A - NA</div>
                        <div>B - Hd SC</div>
                        <div>C - Hd AeC</div>
                        <div>D - NA</div>
                        <div>E - Hd PPC</div>
                        <div className="mt-3 pt-2 text-xs text-muted-foreground">Refer to LRU Category</div>
                      </div>
                    </TableCell>
                    <TableCell>CO 805</TableCell>

                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Base aircraft</TableCell>
                    <TableCell>1900H to end of shift</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell>NA</TableCell>

                    <TableCell>Night Supt</TableCell>
                    <TableCell>Inform CO 80X after approval is given</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Short Term Detachment/ Exercise</TableCell>
                    <TableCell>All requests</TableCell>
                    <TableCell>OC IMF / DY OC IMF</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell>CO 805</TableCell>

                    <TableCell>DY Ex Dir (Logs) / DY CDC (Logs) / Det Comd</TableCell>
                    <TableCell>Inform CO 80X after approval is given</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Perm Detachment</TableCell>
                    <TableCell>All requests</TableCell>
                    <TableCell>OIC Engrg</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell>NA</TableCell>
                    <TableCell>SMO</TableCell>
                    <TableCell />
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">Phase/Project Aircraft</TableCell>
                    <TableCell>All requests</TableCell>
                    <TableCell>OC MCF</TableCell>
                    <TableCell>PMT</TableCell>
                    <TableCell>FAC SO1/SO2</TableCell>
                    <TableCell>HFAB2</TableCell>
                    <TableCell />
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </div>
        </FormSection>

        <FormSection number="6" title="ES (R) WORKFLOW">
          <TextField
            label="ES Notification Number"
            value={record.esNotificationNumber}
            inputMode="numeric"
            placeholder="Numbers only"
            onChange={(value: string) => onChange('esNotificationNumber', value.replace(/\D/g, ''))}
          />
          <MultilineField
            label="Additional remarks"
            value={record.note}
            onChange={(value: string) => onChange('note', value)}
          />
        </FormSection>

        <div className="print-hidden flex justify-end">
          <Button type="button" onClick={onSubmit}>
            <Send className="h-4 w-4" aria-hidden="true" />
            Review request
          </Button>
        </div>
      </CardContent>
    </Card>
  );

}

type FormSectionProps = {
  number: string;
  title: string;
  children: React.ReactNode;
};

function FormSection({ number, title, children }: FormSectionProps) {
  return (
    <section className="overflow-hidden rounded-lg border border-border bg-card text-card-foreground">
      <div className="flex items-center gap-3 border-b border-border bg-muted px-4 py-3 text-foreground">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
          {number}
        </span>
        <h3 className="font-semibold uppercase">{title}</h3>
      </div>
      <div className="grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3">{children}</div>
    </section>
  );
}

type TextFieldProps = {
  label: string;
  value: string;
  inputMode?: React.HTMLAttributes<HTMLInputElement>['inputMode'];
  placeholder?: string;
  required?: boolean;
  error?: boolean;
  onChange: (value: string) => void;
};

function TextField({ label, value, inputMode, placeholder, required = false, error = false, onChange }: TextFieldProps) {
  return (
    <label className="space-y-1 text-sm font-medium text-foreground">
      {label}{required && <span aria-hidden="true"> *</span>}
      <Input
        value={value}
        placeholder={placeholder}
        inputMode={inputMode}
        required={required}
        aria-invalid={error}
        onChange={(event: React.ChangeEvent<HTMLInputElement>) => onChange(event.target.value)}
        className="bg-background text-foreground"
      />
      {error && <span className="text-sm text-destructive">This field is required.</span>}
    </label>
  );
}


type MultilineFieldProps = {
  label: string;
  value: string;
  placeholder?: string;
  onChange: (value: string) => void;
};

function MultilineField({ label, value, placeholder, onChange }: MultilineFieldProps) {
  return (
    <label className="space-y-1 text-sm font-medium text-foreground sm:col-span-2 lg:col-span-3">
      {label}
      <Textarea
        value={value}
        placeholder={placeholder}
        onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => onChange(event.target.value)}
        className="min-h-24 resize-y bg-background text-foreground"
      />
    </label>
  );
}

type DatePickerFieldProps = {
  label: string;
  value: string;
  required?: boolean;
  error?: boolean;
  onChange: (value: string) => void;
};

function DatePickerField({ label, value, required = false, error = false, onChange }: DatePickerFieldProps) {
  const selectedDate = getDateFromValue(value);

  return (
    <label className="space-y-1 text-sm font-medium text-foreground">
      {label}{required && <span aria-hidden="true"> *</span>}
      <Popover>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            aria-invalid={error}
            className={cn('min-h-11 w-full justify-start bg-background text-left font-normal text-foreground', !selectedDate && 'text-muted-foreground')}
          >
            <CalendarIcon className="mr-2 h-4 w-4" aria-hidden="true" />
            {selectedDate ? format(selectedDate, 'PPP') : <span>Select date</span>}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[calc(100vw-2rem)] p-0 sm:w-auto" align="start">

          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={(date: Date | undefined) => onChange(date ? format(date, 'yyyy-MM-dd') : '')}
            initialFocus
          />
        </PopoverContent>
      </Popover>
      {error && <span className="text-sm text-destructive">This field is required.</span>}
    </label>
  );

}

type CardSelectProps = {
  label: string;
  value: string;
  options: string[];
  required?: boolean;
  error?: boolean;
  allowNone?: boolean;
  onChange: (value: string) => void;
};

function CardSelect({ label, value, options, required = false, error = false, allowNone = false, onChange }: CardSelectProps) {
  return (
    <label className="space-y-1 text-sm font-medium text-foreground">
      {label}{required && <span aria-hidden="true"> *</span>}
      <Select value={allowNone && !value ? 'none' : value} onValueChange={(selectedValue: string) => onChange(selectedValue === 'none' ? '' : selectedValue)}>
        <SelectTrigger className="min-h-11 bg-background text-foreground" aria-label={label} aria-invalid={error}>
          <SelectValue placeholder={label} />
        </SelectTrigger>
        <SelectContent>
          {allowNone && <SelectItem value="none">None</SelectItem>}
          {options.filter((option: string) => option).map((option: string) => (
            <SelectItem key={option} value={option}>
              {option}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {error && <span className="text-sm text-destructive">This field is required.</span>}
    </label>
  );
}
