import { z } from 'zod';

/**
 * Zod schema for CannibalisationRequestRegister validation
 */
export const CannibalisationRequestRegisterSchema = z.object({
  id: z.string().uuid(),
  newColumn: z.string().min(1, { message: "New column is required" }),
});

/**
 * Schema for creating a new CannibalisationRequestRegister (omits system-generated ID)
 */
export const CreateCannibalisationRequestRegisterSchema = CannibalisationRequestRegisterSchema.omit({ id: true });

/**
 * Schema for updating an existing CannibalisationRequestRegister
 */
export const UpdateCannibalisationRequestRegisterSchema = CannibalisationRequestRegisterSchema;

export type CannibalisationRequestRegisterInput = z.infer<typeof CannibalisationRequestRegisterSchema>;
export type CreateCannibalisationRequestRegisterInput = z.infer<typeof CreateCannibalisationRequestRegisterSchema>;
export type UpdateCannibalisationRequestRegisterInput = z.infer<typeof UpdateCannibalisationRequestRegisterSchema>;