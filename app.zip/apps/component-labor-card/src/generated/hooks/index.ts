export * from './use-cannibalisation-request-register';

export const HAS_IN_MEMORY_TABLES = false as const;