import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CannibalisationRequestRegisterService } from "../services/cannibalisation-request-register-service";
import type { CannibalisationRequestRegister } from "../models/cannibalisation-request-register-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all CannibalisationRequestRegister records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, newColumn
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useCannibalisationRequestRegisterList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["cannibalisationRequestRegister-list", options],
    queryFn: () => CannibalisationRequestRegisterService.getAll(options),
  });
}

/**
 * Retrieve a single CannibalisationRequestRegister record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useCannibalisationRequestRegister(id: string) {
  return useQuery({
    queryKey: ["cannibalisationRequestRegister", id],
    queryFn: () => CannibalisationRequestRegisterService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new CannibalisationRequestRegister record.
 * @remarks Form validation: use CreateCannibalisationRequestRegisterSchema with zodResolver for type-safe create forms
 */
export function useCreateCannibalisationRequestRegister() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<CannibalisationRequestRegister, "id">) => CannibalisationRequestRegisterService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["cannibalisationRequestRegister-list"] });
    },
  });
}

/**
 * Update an existing CannibalisationRequestRegister record.
 * @remarks Form validation: use UpdateCannibalisationRequestRegisterSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateCannibalisationRequestRegister() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<CannibalisationRequestRegister, "id">>;
    }) => CannibalisationRequestRegisterService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["cannibalisationRequestRegister-list"] });
      client.invalidateQueries({ queryKey: ["cannibalisationRequestRegister", variables.id] });
    },
  });
}

/**
 * Delete a CannibalisationRequestRegister record by its unique identifier.
 */
export function useDeleteCannibalisationRequestRegister() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => CannibalisationRequestRegisterService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["cannibalisationRequestRegister-list"] });
      client.invalidateQueries({ queryKey: ["cannibalisationRequestRegister", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const CannibalisationRequestRegister_DATA_SOURCE_TYPE = 'Dataverse' as const;

export { CannibalisationRequestRegisterSchema, CreateCannibalisationRequestRegisterSchema, UpdateCannibalisationRequestRegisterSchema } from "../validators/cannibalisation-request-register-validator";
export type { CannibalisationRequestRegisterInput, CreateCannibalisationRequestRegisterInput, UpdateCannibalisationRequestRegisterInput } from "../validators/cannibalisation-request-register-validator";